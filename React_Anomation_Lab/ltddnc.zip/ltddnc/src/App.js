import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import FadeText from "./components/FadeText";
import MovingShape from "./components/MovingShape";
import BellAnimation from "./components/BellAnimation";
import Balloons from "./components/Balloons";
import ShopeeAd from "./components/ShopeeAd";
import CatAndMouse from "./components/CatAndMouse";
import "./App.css";

function App() {
  return (
    <Router>
      <div className="container">
        <h1>React Animation Lab</h1>
        <nav>
          <ul>
            <li><Link to="/fade-text">Fade Text</Link></li>
            <li><Link to="/moving-shape">Moving Shape</Link></li>
            <li><Link to="/bell-animation">Bell Animation</Link></li>
            <li><Link to="/balloons">Balloons</Link></li>
            <li><Link to="/shopee-ad">Shopee Ad</Link></li>
            <li><Link to="/cat-and-mouse">Cat & Mouse</Link></li>
          </ul>
        </nav>
        <Routes>
          <Route path="/fade-text" element={<FadeText />} />
          <Route path="/moving-shape" element={<MovingShape />} />
          <Route path="/bell-animation" element={<BellAnimation />} />
          <Route path="/balloons" element={<Balloons />} />
          <Route path="/shopee-ad" element={<ShopeeAd />} />
          <Route path="/cat-and-mouse" element={<CatAndMouse />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
