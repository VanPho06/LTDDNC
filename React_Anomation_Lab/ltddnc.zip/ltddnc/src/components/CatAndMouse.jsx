import { useState } from "react";

function CatAndMouse() {
  const [catPos, setCatPos] = useState(0);
  const [mousePos, setMousePos] = useState(100);
  return (
    <div>
      <div style={{ transform: `translateX(${mousePos}px)`, transition: "1s" }}>🐭</div>
      <div style={{ transform: `translateY(${catPos}px)`, transition: "1s" }}>🐱</div>
      <button onClick={() => setMousePos(mousePos + 50)}>Move Mouse</button>
      <button onClick={() => setCatPos(catPos + 50)}>Move Cat</button>
    </div>
  );
}

export default CatAndMouse;
