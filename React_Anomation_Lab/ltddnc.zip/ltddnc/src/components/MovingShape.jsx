import { useState } from "react";

function MovingShape() {
  const [position, setPosition] = useState(0);
  return (
    <div>
      <div style={{ transform: `translateX(${position}px)`, transition: "1s" }}>⬛</div>
      <button onClick={() => setPosition(position + 100)}>Start</button>
      <button onClick={() => setPosition(0)}>Restart</button>
    </div>
  );
}

export default MovingShape;
