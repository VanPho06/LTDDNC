import { useState } from "react";

function ShopeeAd() {
  const [scale, setScale] = useState(1);
  return (
    <div>
      <h2 style={{ transform: `scale(${scale})`, transition: "1s" }} onClick={() => setScale(1.5)}>Shopee cái gì cũng có...</h2>
    </div>
  );
}

export default ShopeeAd;
