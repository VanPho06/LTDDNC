import { useState } from "react";

function Balloons() {
  const [position, setPosition] = useState(500);
  return (
    <div>
      <div style={{ transform: `translateY(${position}px)`, transition: "5s" }}>🎈</div>
      <button onClick={() => setPosition(-500)}>Fly</button>
    </div>
  );
}

export default Balloons;
