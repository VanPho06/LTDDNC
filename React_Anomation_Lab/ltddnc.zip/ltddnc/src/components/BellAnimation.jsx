import { useState } from "react";

function BellAnimation() {
  const [rotate, setRotate] = useState(0);
  return <div style={{ transform: `rotate(${rotate}deg)`, transition: "0.5s" }} onMouseEnter={() => setRotate(30)}>🔔</div>;
}

export default BellAnimation;
