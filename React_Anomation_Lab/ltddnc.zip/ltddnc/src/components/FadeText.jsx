import { useState, useEffect } from "react";

function FadeText() {
  const [opacity, setOpacity] = useState(0);
  useEffect(() => {
    let timer = setTimeout(() => setOpacity(1), 3000);
    return () => clearTimeout(timer);
  }, []);
  return <h2 style={{ opacity, transition: "opacity 3s" }}>Hello, React Animation!</h2>;
}

export default FadeText;
